GRANT ALL ON public.app_users TO service_role;
GRANT ALL ON public.app_sessions TO service_role;
GRANT ALL ON public.assets TO service_role;
GRANT ALL ON public.asset_history TO service_role;
GRANT ALL ON public.tickets TO service_role;
GRANT ALL ON public.troubleshoots TO service_role;
GRANT ALL ON public.audit_logs TO service_role;

REVOKE ALL ON public.app_users FROM anon, authenticated;
REVOKE ALL ON public.app_sessions FROM anon, authenticated;
REVOKE ALL ON public.assets FROM anon, authenticated;
REVOKE ALL ON public.asset_history FROM anon, authenticated;
REVOKE ALL ON public.tickets FROM anon, authenticated;
REVOKE ALL ON public.troubleshoots FROM anon, authenticated;
REVOKE ALL ON public.audit_logs FROM anon, authenticated;

CREATE INDEX IF NOT EXISTS idx_app_sessions_expires ON public.app_sessions (expires_at);
CREATE INDEX IF NOT EXISTS idx_asset_history_asset ON public.asset_history (asset_id);