CREATE TABLE public.app_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_by text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.app_settings TO service_role;
REVOKE ALL ON public.app_settings FROM anon, authenticated;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
INSERT INTO public.app_settings (key, value) VALUES
 ('domains', '{"items":[]}'::jsonb),
 ('drive', '{"folderId":"","folderName":"","autoUpload":false}'::jsonb),
 ('email', '{"enabled":false,"senderName":"NexaITSM Support","senderEmail":"","replyTo":"","subject":"Reset password akun NexaITSM","body":"Halo {{nama}},\n\nKlik tautan berikut untuk mengatur ulang password Anda: {{link}}\nTautan berlaku {{menit}} menit.\n\nSalam,\nTim IT","linkExpiryMinutes":30}'::jsonb);