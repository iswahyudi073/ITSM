import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { getSession, getToken, hydrate, type Session } from "@/lib/itsm-store";

/** Re-renders whenever the ITSM cache changes, and refreshes it from the database. */
export function useStoreVersion() {
  const [version, setVersion] = useState(0);
  useEffect(() => {
    void hydrate(true);
    setVersion((v) => v + 1);
    const handler = () => setVersion((v) => v + 1);
    window.addEventListener("deancaitsm:changed", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("deancaitsm:changed", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return { version, refresh: useCallback(() => setVersion((v) => v + 1), []) };
}

export function useSession() {
  const { version } = useStoreVersion();
  const [session, setSessionState] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    setSessionState(getSession());
    if (!getToken() || getSession()) setReady(true);
  }, [version]);
  return { session, ready };
}

/** Client-side guard for the app shell pages. */
export function useRequireAuth() {
  const { session, ready } = useSession();
  const navigate = useNavigate();
  useEffect(() => {
    if (ready && !session) navigate({ to: "/", replace: true });
  }, [ready, session, navigate]);
  return { session, ready };
}
