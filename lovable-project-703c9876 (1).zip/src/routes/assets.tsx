import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus, Printer, FileSpreadsheet, History, Pencil } from "lucide-react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import {
  downloadCSV,
  formatDate,
  getAssets,
  getTickets,
  logAssetChange,
  nextId,
  nowISO,
  saveAssets,
  type Asset,
  type AssetStatus,
} from "@/lib/itsm-store";

export const Route = createFileRoute("/assets")({
  head: () => ({
    meta: [
      { title: "Aset & Inventaris IT — DeancaITSM" },
      {
        name: "description",
        content:
          "Inventaris aset IT dengan status, lokasi, pemilik, filter, dan riwayat perubahan beserta audit trail.",
      },
      { property: "og:title", content: "Aset & Inventaris IT — DeancaITSM" },
      {
        property: "og:description",
        content: "Kelola aset IT: status, lokasi, pemilik, dan riwayat perubahan.",
      },
    ],
  }),
  component: AssetsPage,
});

const STATUSES: AssetStatus[] = ["In Use", "In Stock", "Maintenance", "Retired"];

function AssetsPage() {
  const { session } = useRequireAuth();
  const { refresh } = useStoreVersion();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [type, setType] = useState("all");
  const [editing, setEditing] = useState<Asset | null>(null);
  const [showForm, setShowForm] = useState(false);

  const assets = getAssets();
  const tickets = getTickets();
  const types = Array.from(new Set(assets.map((a) => a.type)));

  const filtered = useMemo(
    () =>
      assets.filter((a) => {
        const q = query.toLowerCase();
        const matchQ =
          !q || [a.id, a.name, a.owner, a.location, a.serial].join(" ").toLowerCase().includes(q);
        return (
          matchQ && (status === "all" || a.status === status) && (type === "all" || a.type === type)
        );
      }),
    [assets, query, status, type],
  );

  if (!session) return null;

  const openCreate = () => {
    setEditing(null);
    setShowForm(true);
  };
  const openEdit = (asset: Asset) => {
    setEditing(asset);
    setShowForm(true);
  };

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = {
      name: String(fd.get("name") || ""),
      type: String(fd.get("type") || "Lainnya"),
      owner: String(fd.get("owner") || "-"),
      location: String(fd.get("location") || "-"),
      status: String(fd.get("status") || "In Use") as AssetStatus,
      serial: String(fd.get("serial") || "-"),
    };
    const list = getAssets();

    if (editing) {
      const diff = (Object.keys(data) as (keyof typeof data)[])
        .filter((k) => editing[k] !== data[k])
        .map((k) => `${k}: "${editing[k]}" → "${data[k]}"`)
        .join("; ");
      saveAssets(
        list.map((a) => (a.id === editing.id ? { ...a, ...data, updatedAt: nowISO() } : a)),
      );
      logAssetChange({
        assetId: editing.id,
        action: "Update aset",
        changes: diff || "Tidak ada perubahan nilai",
        changedBy: `${session.fullName} (${session.username})`,
      });
    } else {
      const id = nextId(
        "AST",
        list.map((a) => a.id),
      );
      saveAssets([...list, { id, ...data, createdAt: nowISO(), updatedAt: nowISO() }]);
      logAssetChange({
        assetId: id,
        action: "Aset dibuat",
        changes: `${data.name} · ${data.type} · ${data.location} · ${data.status}`,
        changedBy: `${session.fullName} (${session.username})`,
      });
    }
    setShowForm(false);
    setEditing(null);
    refresh();
  };

  const exportCSV = () =>
    downloadCSV(
      `laporan-aset-${new Date().toISOString().slice(0, 10)}.csv`,
      filtered.map((a) => ({
        "ID Aset": a.id,
        Nama: a.name,
        Tipe: a.type,
        "Serial Number": a.serial,
        Pemilik: a.owner,
        Lokasi: a.location,
        Status: a.status,
        "Ticket Terkait":
          tickets
            .filter((t) => t.assetId === a.id)
            .map((t) => t.id)
            .join(" | ") || "-",
        "Terakhir Diubah": formatDate(a.updatedAt),
      })),
    );

  return (
    <AppShell
      session={session}
      title="Aset & Inventaris"
      description="Data aset IT beserta status, lokasi, dan riwayat perubahan"
      actions={
        <>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="size-4" /> Print / PDF
          </Button>
          <Button variant="outline" size="sm" onClick={exportCSV}>
            <FileSpreadsheet className="size-4" /> Export CSV
          </Button>
          <Button size="sm" onClick={openCreate}>
            <Plus className="size-4" /> Aset Baru
          </Button>
        </>
      }
    >
      {showForm && (
        <form onSubmit={submit} className="panel no-print space-y-4 p-5">
          <h2 className="text-sm font-semibold">
            {editing ? `Edit Aset ${editing.id}` : "Tambah Aset Baru"}
          </h2>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2 md:col-span-2">
              <Label>Nama Aset</Label>
              <Input name="name" required defaultValue={editing?.name} />
            </div>
            <div className="space-y-2">
              <Label>Tipe</Label>
              <Input name="type" defaultValue={editing?.type ?? "Laptop"} />
            </div>
            <div className="space-y-2">
              <Label>Serial Number</Label>
              <Input name="serial" defaultValue={editing?.serial} />
            </div>
            <div className="space-y-2">
              <Label>Pemilik</Label>
              <Input name="owner" defaultValue={editing?.owner} />
            </div>
            <div className="space-y-2">
              <Label>Lokasi</Label>
              <Input name="location" defaultValue={editing?.location} />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <select
                name="status"
                defaultValue={editing?.status ?? "In Use"}
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
              >
                {STATUSES.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex gap-2">
            <Button type="submit" size="sm">
              Simpan
            </Button>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={() => {
                setShowForm(false);
                setEditing(null);
              }}
            >
              Batal
            </Button>
          </div>
        </form>
      )}

      <div className="panel no-print flex flex-wrap gap-3 p-4">
        <Input
          placeholder="Cari aset, pemilik, lokasi..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="max-w-xs"
        />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        >
          <option value="all">Semua Status</option>
          {STATUSES.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        >
          <option value="all">Semua Tipe</option>
          {types.map((t) => (
            <option key={t}>{t}</option>
          ))}
        </select>
      </div>

      <div className="panel print-area overflow-hidden">
        <div className="border-b px-5 py-4">
          <h2 className="text-sm font-semibold">Daftar Aset ({filtered.length})</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Nama</th>
                <th className="px-4 py-3">Tipe</th>
                <th className="px-4 py-3">Pemilik</th>
                <th className="px-4 py-3">Lokasi</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Ticket Terkait</th>
                <th className="no-print px-4 py-3">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => (
                <tr key={a.id} className="border-t">
                  <td className="px-4 py-3 font-mono text-xs">{a.id}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium">{a.name}</p>
                    <p className="text-xs text-muted-foreground">{a.serial}</p>
                  </td>
                  <td className="px-4 py-3">{a.type}</td>
                  <td className="px-4 py-3">{a.owner}</td>
                  <td className="px-4 py-3">{a.location}</td>
                  <td className="px-4 py-3">
                    <StatusPill value={a.status} />
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">
                    {tickets
                      .filter((t) => t.assetId === a.id)
                      .map((t) => t.id)
                      .join(", ") || "-"}
                  </td>
                  <td className="no-print px-4 py-3">
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(a)}>
                        <Pencil className="size-4" />
                      </Button>
                      <Button size="sm" variant="ghost" asChild>
                        <Link to="/assets/$assetId" params={{ assetId: a.id }}>
                          <History className="size-4" />
                        </Link>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {!filtered.length && (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-muted-foreground">
                    Tidak ada aset yang cocok dengan filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
