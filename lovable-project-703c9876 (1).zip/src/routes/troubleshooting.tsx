import { useMemo, useState } from "react";
import { toast } from "sonner";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, Printer, FileSpreadsheet, HardDriveUpload } from "lucide-react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import {
  downloadXLSX,
  formatDate,
  getAssets,
  getTickets,
  getTroubles,
  nextId,
  nowISO,
  uploadReportToDrive,
  saveTroubles,
  type Troubleshoot,
} from "@/lib/itsm-store";

export const Route = createFileRoute("/troubleshooting")({
  head: () => ({
    meta: [
      { title: "Log Troubleshooting IT — DeancaITSM" },
      {
        name: "description",
        content:
          "Catat masalah, akar penyebab, tindakan penanganan, dan hasil troubleshooting untuk setiap ticket dan aset terdampak.",
      },
      { property: "og:title", content: "Log Troubleshooting IT — DeancaITSM" },
      {
        property: "og:description",
        content: "Dokumentasi root cause, tindakan, dan hasil penanganan insiden IT.",
      },
    ],
  }),
  component: TroubleshootingPage,
});

function TroubleshootingPage() {
  const { session } = useRequireAuth();
  const { refresh } = useStoreVersion();
  const [query, setQuery] = useState("");
  const [result, setResult] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");

  const troubles = getTroubles();
  const tickets = getTickets();
  const assets = getAssets();

  const filtered = useMemo(
    () =>
      troubles.filter((t) => {
        const q = query.toLowerCase();
        const matchQ =
          !q ||
          [t.id, t.ticketId, t.assetId, t.problem, t.rootCause, t.action, t.handledBy]
            .join(" ")
            .toLowerCase()
            .includes(q);
        return matchQ && (result === "all" || t.result === result);
      }),
    [troubles, query, result],
  );

  if (!session) return null;

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const ticketId = String(fd.get("ticketId") || "")
      .trim()
      .toUpperCase();
    const assetId = String(fd.get("assetId") || "")
      .trim()
      .toUpperCase();
    if (ticketId && !tickets.some((t) => t.id === ticketId)) {
      setError(`Ticket ${ticketId} tidak ditemukan.`);
      return;
    }
    if (assetId && !assets.some((a) => a.id === assetId)) {
      setError(`Aset ${assetId} tidak ditemukan pada inventaris.`);
      return;
    }
    const list = getTroubles();
    const entry: Troubleshoot = {
      id: nextId(
        "TS",
        list.map((t) => t.id),
      ),
      ticketId,
      assetId,
      problem: String(fd.get("problem") || ""),
      rootCause: String(fd.get("rootCause") || ""),
      action: String(fd.get("action") || ""),
      result: String(fd.get("result") || "Resolved") as Troubleshoot["result"],
      handledBy: String(fd.get("handledBy") || session.fullName),
      createdAt: nowISO(),
    };
    saveTroubles([entry, ...list]);
    setError("");
    setShowForm(false);
    refresh();
  };

  const reportRows = () =>
    filtered.map((t) => ({
      "ID Log": t.id,
      "ID Ticket": t.ticketId || "-",
      "ID Aset": t.assetId || "-",
      Masalah: t.problem,
      "Akar Penyebab": t.rootCause,
      Tindakan: t.action,
      Hasil: t.result,
      Teknisi: t.handledBy,
      Tanggal: formatDate(t.createdAt),
    }));

  const reportName = () => `laporan-troubleshooting-${new Date().toISOString().slice(0, 10)}.xlsx`;
  const exportExcel = () => downloadXLSX(reportName(), reportRows());
  const uploadDrive = async () => {
    const res = await uploadReportToDrive(reportName(), reportRows());
    if (res.ok) toast.success("Laporan terkirim ke Google Drive", { description: res.link });
    else toast.error(res.error ?? "Upload gagal.");
  };

  return (
    <AppShell
      session={session}
      title="Troubleshooting"
      description="Dokumentasi penanganan insiden dan akar penyebab"
      actions={
        <>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="size-4" /> Print PDF
          </Button>
          <Button variant="outline" size="sm" onClick={exportExcel}>
            <FileSpreadsheet className="size-4" /> Export Excel
          </Button>
          <Button variant="outline" size="sm" onClick={() => void uploadDrive()}>
            <HardDriveUpload className="size-4" /> Google Drive
          </Button>
          <Button size="sm" onClick={() => setShowForm((v) => !v)}>
            <Plus className="size-4" /> Log Baru
          </Button>
        </>
      }
    >
      {showForm && (
        <form className="panel no-print space-y-4 p-5" onSubmit={submit}>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="ticketId">ID Ticket terkait</Label>
              <Input id="ticketId" name="ticketId" placeholder="TKT-1001" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="assetId">ID Aset terdampak</Label>
              <Input id="assetId" name="assetId" placeholder="AST-001" />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="problem">Masalah</Label>
              <Input id="problem" name="problem" required />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="rootCause">Akar penyebab</Label>
              <Textarea id="rootCause" name="rootCause" rows={2} required />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="action">Tindakan penanganan</Label>
              <Textarea id="action" name="action" rows={3} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="result">Hasil</Label>
              <select
                id="result"
                name="result"
                className="h-10 w-full rounded-md border bg-background px-3 text-sm"
              >
                <option>Resolved</option>
                <option>Escalated</option>
                <option>Monitoring</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="handledBy">Ditangani oleh</Label>
              <Input id="handledBy" name="handledBy" defaultValue={session.fullName} />
            </div>
          </div>
          {error && (
            <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          )}
          <div className="flex gap-2">
            <Button type="submit">Simpan log</Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>
              Batal
            </Button>
          </div>
        </form>
      )}

      <div className="no-print grid gap-3 md:grid-cols-[1fr_200px]">
        <Input
          placeholder="Cari masalah, ticket, aset, teknisi…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select
          className="h-10 rounded-md border bg-background px-3 text-sm"
          value={result}
          onChange={(e) => setResult(e.target.value)}
        >
          <option value="all">Semua hasil</option>
          <option value="Resolved">Resolved</option>
          <option value="Escalated">Escalated</option>
          <option value="Monitoring">Monitoring</option>
        </select>
      </div>

      <div className="panel print-area overflow-x-auto">
        <table className="w-full min-w-[900px] text-sm">
          <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">ID</th>
              <th className="px-4 py-3">Masalah</th>
              <th className="px-4 py-3">Akar penyebab</th>
              <th className="px-4 py-3">Tindakan</th>
              <th className="px-4 py-3">Ticket / Aset</th>
              <th className="px-4 py-3">Hasil</th>
              <th className="px-4 py-3">Teknisi</th>
              <th className="px-4 py-3">Tanggal</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((t) => (
              <tr key={t.id} className="border-t align-top">
                <td className="px-4 py-3 font-mono text-xs">{t.id}</td>
                <td className="px-4 py-3 font-medium">{t.problem}</td>
                <td className="px-4 py-3 text-muted-foreground">{t.rootCause}</td>
                <td className="px-4 py-3 text-muted-foreground">{t.action}</td>
                <td className="px-4 py-3 font-mono text-xs">
                  {t.ticketId || "-"} / {t.assetId || "-"}
                </td>
                <td className="px-4 py-3">
                  <StatusPill value={t.result} />
                </td>
                <td className="px-4 py-3">{t.handledBy}</td>
                <td className="px-4 py-3 text-muted-foreground">{formatDate(t.createdAt)}</td>
              </tr>
            ))}
            {!filtered.length && (
              <tr>
                <td className="px-4 py-8 text-center text-muted-foreground" colSpan={8}>
                  Belum ada log troubleshooting.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
