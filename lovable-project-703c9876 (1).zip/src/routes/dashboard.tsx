import { createFileRoute, Link } from "@tanstack/react-router";
import { Ticket as TicketIcon, AlertTriangle, CheckCircle2, Boxes, Wrench } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell, StatusPill } from "@/components/AppShell";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import { formatDate, getAssets, getTickets, getTroubles } from "@/lib/itsm-store";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard Operasional IT — DeancaITSM" },
      {
        name: "description",
        content:
          "Ringkasan ticket aktif, insiden prioritas tinggi, status aset, dan aktivitas troubleshooting terbaru.",
      },
      { property: "og:title", content: "Dashboard Operasional IT — DeancaITSM" },
      {
        property: "og:description",
        content: "Ringkasan ticket, aset, dan troubleshooting IT support.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { session } = useRequireAuth();
  useStoreVersion();
  if (!session) return null;

  const tickets = getTickets();
  const assets = getAssets();
  const troubles = getTroubles();

  const open = tickets.filter((t) => !["Resolved", "Closed"].includes(t.status)).length;
  const high = tickets.filter((t) => t.priority === "High").length;
  const resolved = tickets.filter((t) => ["Resolved", "Closed"].includes(t.status)).length;

  const statusData = ["Open", "In Progress", "Pending", "Resolved", "Closed"].map((s) => ({
    name: s,
    total: tickets.filter((t) => t.status === s).length,
  }));

  const locationData = Array.from(
    assets.reduce((map, a) => {
      const key = a.location?.trim() || "Tanpa lokasi";
      return map.set(key, (map.get(key) ?? 0) + 1);
    }, new Map<string, number>()),
  )
    .map(([name, total]) => ({ name, total }))
    .sort((a, b) => b.total - a.total);

  const resolvedTickets = tickets.filter((t) => ["Resolved", "Closed"].includes(t.status));
  const resolutionRate = tickets.length
    ? Math.round((resolvedTickets.length / tickets.length) * 100)
    : 0;
  const avgHours = resolvedTickets.length
    ? resolvedTickets.reduce(
        (sum, t) =>
          sum + (new Date(t.updatedAt).getTime() - new Date(t.createdAt).getTime()) / 3_600_000,
        0,
      ) / resolvedTickets.length
    : 0;
  const avgLabel = !resolvedTickets.length
    ? "-"
    : avgHours < 24
      ? `${avgHours.toFixed(1)} jam`
      : `${(avgHours / 24).toFixed(1)} hari`;

  const assetData = ["In Use", "In Stock", "Maintenance", "Retired"].map((s) => ({
    name: s,
    value: assets.filter((a) => a.status === s).length,
  }));
  const pieColors = [
    "var(--color-chart-1)",
    "var(--color-chart-5)",
    "var(--color-chart-3)",
    "var(--color-chart-4)",
  ];

  const stats = [
    { label: "Ticket Aktif", value: open, icon: TicketIcon },
    { label: "Prioritas Tinggi", value: high, icon: AlertTriangle },
    { label: "Selesai", value: resolved, icon: CheckCircle2 },
    { label: "Total Aset", value: assets.length, icon: Boxes },
    { label: "Log Troubleshooting", value: troubles.length, icon: Wrench },
  ];

  return (
    <AppShell
      session={session}
      title={`Selamat datang, ${session.fullName}`}
      description="Ringkasan operasional IT support & infrastruktur"
    >
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="panel p-5">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">{label}</p>
              <Icon className="size-4 text-primary" />
            </div>
            <p className="mt-3 text-3xl font-semibold">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="panel p-5">
          <p className="text-sm text-muted-foreground">Tingkat Penyelesaian</p>
          <p className="mt-2 text-3xl font-semibold">{resolutionRate}%</p>
          <div className="mt-3 h-2 w-full rounded-full bg-muted">
            <div className="h-2 rounded-full bg-primary" style={{ width: `${resolutionRate}%` }} />
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            {resolvedTickets.length} dari {tickets.length} ticket selesai
          </p>
        </div>
        <div className="panel p-5">
          <p className="text-sm text-muted-foreground">Rata-rata Waktu Penyelesaian</p>
          <p className="mt-2 text-3xl font-semibold">{avgLabel}</p>
          <p className="mt-3 text-xs text-muted-foreground">
            Dihitung dari selisih waktu dibuat sampai ticket ditutup.
          </p>
        </div>
      </div>

      <div className="panel p-5">
        <h2 className="text-sm font-semibold">Aset per Lokasi</h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={locationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="name" fontSize={12} stroke="var(--color-muted-foreground)" />
              <YAxis allowDecimals={false} fontSize={12} stroke="var(--color-muted-foreground)" />
              <Tooltip />
              <Bar dataKey="total" fill="var(--color-chart-2)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5 lg:col-span-2">
          <h2 className="text-sm font-semibold">Distribusi Status Ticket</h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statusData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="name" fontSize={12} stroke="var(--color-muted-foreground)" />
                <YAxis allowDecimals={false} fontSize={12} stroke="var(--color-muted-foreground)" />
                <Tooltip />
                <Bar dataKey="total" fill="var(--color-chart-1)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="panel p-5">
          <h2 className="text-sm font-semibold">Status Aset</h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={assetData}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={45}
                  outerRadius={80}
                >
                  {assetData.map((_, i) => (
                    <Cell key={i} fill={pieColors[i % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
            {assetData.map((d, i) => (
              <li key={d.name} className="flex items-center gap-2">
                <span
                  className="size-2.5 rounded-full"
                  style={{ background: pieColors[i % pieColors.length] }}
                />
                {d.name} — {d.value}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="panel overflow-hidden">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <h2 className="text-sm font-semibold">Ticket Terbaru</h2>
          <Link to="/tickets" className="text-sm font-medium text-primary hover:underline">
            Lihat semua
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-5 py-3">ID</th>
                <th className="px-5 py-3">Masalah</th>
                <th className="px-5 py-3">Requester</th>
                <th className="px-5 py-3">Aset</th>
                <th className="px-5 py-3">Prioritas</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3">Dibuat</th>
              </tr>
            </thead>
            <tbody>
              {tickets.slice(0, 6).map((t) => (
                <tr key={t.id} className="border-t">
                  <td className="px-5 py-3 font-mono text-xs">{t.id}</td>
                  <td className="px-5 py-3">{t.title}</td>
                  <td className="px-5 py-3">{t.requester}</td>
                  <td className="px-5 py-3 font-mono text-xs">{t.assetId || "-"}</td>
                  <td className="px-5 py-3">
                    <StatusPill value={t.priority} />
                  </td>
                  <td className="px-5 py-3">
                    <StatusPill value={t.status} />
                  </td>
                  <td className="px-5 py-3 text-muted-foreground">{formatDate(t.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
