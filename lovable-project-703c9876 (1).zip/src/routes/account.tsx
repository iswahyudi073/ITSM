import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { KeyRound, Check, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import { PASSWORD_RULES, setUserPassword, validatePassword } from "@/lib/itsm-store";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "Reset Password Akun — DeancaITSM" },
      {
        name: "description",
        content:
          "Ubah password akun DeancaITSM Anda dengan kebijakan keamanan minimal 10 karakter, huruf besar, huruf kecil, angka, dan simbol.",
      },
      { property: "og:title", content: "Reset Password Akun — DeancaITSM" },
      {
        property: "og:description",
        content: "Ganti password akun ITSM sesuai kebijakan keamanan internal.",
      },
    ],
  }),
  component: AccountPage,
});

function AccountPage() {
  const { session } = useRequireAuth();
  const { refresh } = useStoreVersion();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  if (!session) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotice("");
    const issues = validatePassword(next);
    if (issues.length) {
      setError(`Password baru belum memenuhi: ${issues.join(", ")}.`);
      return;
    }
    if (next !== confirm) {
      setError("Konfirmasi password tidak sama.");
      return;
    }
    const res = await setUserPassword({
      targetUserId: session.userId,
      newPassword: next,
      currentPassword: current,
    });
    if (!res.ok) {
      setError(res.error ?? "Gagal mengubah password.");
      return;
    }
    setError("");
    setNotice("Password berhasil diperbarui.");
    setCurrent("");
    setNext("");
    setConfirm("");
    refresh();
  };

  return (
    <AppShell session={session} title="Reset Password" description="Perbarui kredensial akun Anda">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,480px)_1fr]">
        <form className="panel space-y-4 p-6" onSubmit={(e) => void submit(e)}>
          <div className="flex items-center gap-2 text-sm font-medium">
            <KeyRound className="size-4" /> Ganti password — {session.username}
          </div>
          <div className="space-y-2">
            <Label htmlFor="current">Password saat ini</Label>
            <Input
              id="current"
              type="password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="next">Password baru</Label>
            <Input
              id="next"
              type="password"
              value={next}
              onChange={(e) => setNext(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirm">Konfirmasi password baru</Label>
            <Input
              id="confirm"
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
            />
          </div>
          {error && (
            <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          )}
          {notice && (
            <p className="rounded-md bg-success/10 px-3 py-2 text-sm text-success">{notice}</p>
          )}
          <Button type="submit" className="w-full">
            Simpan password baru
          </Button>
        </form>

        <div className="panel space-y-3 p-6">
          <p className="text-sm font-medium">Kebijakan password</p>
          <ul className="space-y-2 text-sm">
            {PASSWORD_RULES.map((rule) => {
              const ok = rule.test(next);
              return (
                <li key={rule.label} className="flex items-center gap-2">
                  {ok ? (
                    <Check className="size-4 text-success" />
                  ) : (
                    <X className="size-4 text-muted-foreground" />
                  )}
                  <span className={ok ? "text-foreground" : "text-muted-foreground"}>
                    {rule.label}
                  </span>
                </li>
              );
            })}
          </ul>
          <p className="text-xs text-muted-foreground">
            Administrator dapat mereset password akun mana pun melalui halaman User & Akses.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
