import { useMemo, useState } from "react";
import { toast } from "sonner";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, Printer, FileSpreadsheet, HardDriveUpload } from "lucide-react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import {
  downloadXLSX,
  formatDate,
  getAssets,
  getTickets,
  nextId,
  nowISO,
  uploadReportToDrive,
  saveTickets,
  type Priority,
  type Ticket,
  type TicketStatus,
  type TicketType,
} from "@/lib/itsm-store";

export const Route = createFileRoute("/tickets")({
  head: () => ({
    meta: [
      { title: "Ticketing IT Support — DeancaITSM" },
      {
        name: "description",
        content:
          "Kelola incident dan service request, hubungkan ticket dengan aset terdampak, lalu cetak PDF atau export CSV.",
      },
      { property: "og:title", content: "Ticketing IT Support — DeancaITSM" },
      {
        property: "og:description",
        content: "Incident, service request, prioritas, requester, dan aset terdampak.",
      },
    ],
  }),
  component: TicketsPage,
});

const STATUSES: TicketStatus[] = ["Open", "In Progress", "Pending", "Resolved", "Closed"];

function TicketsPage() {
  const { session } = useRequireAuth();
  const { refresh } = useStoreVersion();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [priority, setPriority] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");

  const tickets = getTickets();
  const assets = getAssets();

  const filtered = useMemo(
    () =>
      tickets.filter((t) => {
        const q = query.toLowerCase();
        const matchQ =
          !q ||
          [t.id, t.title, t.requester, t.assetId, t.category, t.assignee]
            .join(" ")
            .toLowerCase()
            .includes(q);
        return (
          matchQ &&
          (status === "all" || t.status === status) &&
          (priority === "all" || t.priority === priority)
        );
      }),
    [tickets, query, status, priority],
  );

  if (!session) return null;

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const assetId = String(fd.get("assetId") || "")
      .trim()
      .toUpperCase();
    if (assetId && !assets.some((a) => a.id === assetId)) {
      setError(`Aset ${assetId} tidak ditemukan pada inventaris.`);
      return;
    }
    const list = getTickets();
    const ticket: Ticket = {
      id: nextId(
        "TKT",
        list.map((t) => t.id),
        4,
      ),
      title: String(fd.get("title") || ""),
      description: String(fd.get("description") || ""),
      type: String(fd.get("type") || "Incident") as TicketType,
      category: String(fd.get("category") || "General"),
      priority: String(fd.get("priority") || "Normal") as Priority,
      status: "Open",
      requester: String(fd.get("requester") || session.fullName),
      assignee: String(fd.get("assignee") || "-"),
      assetId,
      createdAt: nowISO(),
      updatedAt: nowISO(),
    };
    saveTickets([ticket, ...list]);
    setError("");
    setShowForm(false);
    refresh();
  };

  const updateStatus = (id: string, next: TicketStatus) => {
    saveTickets(
      getTickets().map((t) => (t.id === id ? { ...t, status: next, updatedAt: nowISO() } : t)),
    );
    refresh();
  };

  const reportRows = () =>
    filtered.map((t) => ({
      "ID Ticket": t.id,
      Masalah: t.title,
      Deskripsi: t.description,
      Tipe: t.type,
      Kategori: t.category,
      Requester: t.requester,
      Teknisi: t.assignee,
      "Aset Terdampak": t.assetId
        ? `${t.assetId} - ${assets.find((a) => a.id === t.assetId)?.name ?? ""}`
        : "-",
      Prioritas: t.priority,
      Status: t.status,
      Dibuat: formatDate(t.createdAt),
    }));

  const reportName = () => `laporan-ticket-${new Date().toISOString().slice(0, 10)}.xlsx`;
  const exportExcel = () => downloadXLSX(reportName(), reportRows());
  const uploadDrive = async () => {
    const res = await uploadReportToDrive(reportName(), reportRows());
    if (res.ok) toast.success("Laporan terkirim ke Google Drive", { description: res.link });
    else toast.error(res.error ?? "Upload gagal.");
  };

  return (
    <AppShell
      session={session}
      title="Ticketing"
      description="Incident & service request IT support"
      actions={
        <>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="size-4" /> Print / PDF
          </Button>
          <Button variant="outline" size="sm" onClick={exportExcel}>
            <FileSpreadsheet className="size-4" /> Export Excel
          </Button>
          <Button variant="outline" size="sm" onClick={() => void uploadDrive()}>
            <HardDriveUpload className="size-4" /> Google Drive
          </Button>
          <Button size="sm" onClick={() => setShowForm((v) => !v)}>
            <Plus className="size-4" /> Ticket Baru
          </Button>
        </>
      }
    >
      {showForm && (
        <form onSubmit={submit} className="panel no-print space-y-4 p-5">
          <h2 className="text-sm font-semibold">Buat Ticket Baru</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <Field label="Judul Masalah" className="md:col-span-2">
              <Input name="title" required placeholder="Contoh: Tidak bisa akses shared folder" />
            </Field>
            <Field label="Kategori">
              <Input name="category" defaultValue="Hardware" />
            </Field>
            <Field label="Tipe">
              <select
                name="type"
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
              >
                <option>Incident</option>
                <option>Service Request</option>
              </select>
            </Field>
            <Field label="Prioritas">
              <select
                name="priority"
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
              >
                <option value="High">High</option>
                <option value="Normal" selected>
                  Normal
                </option>
                <option value="Low">Low</option>
              </select>
            </Field>
            <Field label="Requester">
              <Input name="requester" defaultValue={session.fullName} />
            </Field>
            <Field label="Teknisi">
              <Input name="assignee" placeholder="Nama teknisi" />
            </Field>
            <Field label="Aset Terdampak">
              <select
                name="assetId"
                className="h-9 w-full rounded-md border bg-background px-3 text-sm"
              >
                <option value="">- Tidak ada -</option>
                {assets.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.id} — {a.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Deskripsi" className="md:col-span-3">
              <Textarea name="description" rows={3} />
            </Field>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="flex gap-2">
            <Button type="submit" size="sm">
              Simpan Ticket
            </Button>
            <Button type="button" size="sm" variant="ghost" onClick={() => setShowForm(false)}>
              Batal
            </Button>
          </div>
        </form>
      )}

      <div className="panel no-print flex flex-wrap gap-3 p-4">
        <Input
          placeholder="Cari ticket, requester, atau aset..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="max-w-xs"
        />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        >
          <option value="all">Semua Status</option>
          {STATUSES.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        >
          <option value="all">Semua Prioritas</option>
          <option>High</option>
          <option>Normal</option>
          <option>Low</option>
        </select>
      </div>

      <div className="panel print-area overflow-hidden">
        <div className="border-b px-5 py-4">
          <h2 className="text-sm font-semibold">Laporan Ticket ({filtered.length})</h2>
          <p className="text-xs text-muted-foreground">
            Dicetak pada {formatDate(nowISO())} oleh {session.fullName}
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Masalah</th>
                <th className="px-4 py-3">Tipe</th>
                <th className="px-4 py-3">Requester</th>
                <th className="px-4 py-3">Aset Terdampak</th>
                <th className="px-4 py-3">Prioritas</th>
                <th className="px-4 py-3">Status</th>
                <th className="no-print px-4 py-3">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((t) => (
                <tr key={t.id} className="border-t align-top">
                  <td className="px-4 py-3 font-mono text-xs">{t.id}</td>
                  <td className="px-4 py-3">
                    <p className="font-medium">{t.title}</p>
                    <p className="text-xs text-muted-foreground">{t.category}</p>
                  </td>
                  <td className="px-4 py-3">{t.type}</td>
                  <td className="px-4 py-3">{t.requester}</td>
                  <td className="px-4 py-3">
                    {t.assetId ? (
                      <>
                        <span className="font-mono text-xs">{t.assetId}</span>
                        <p className="text-xs text-muted-foreground">
                          {assets.find((a) => a.id === t.assetId)?.name ?? "-"}
                        </p>
                      </>
                    ) : (
                      "-"
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <StatusPill value={t.priority} />
                  </td>
                  <td className="px-4 py-3">
                    <StatusPill value={t.status} />
                  </td>
                  <td className="no-print px-4 py-3">
                    <select
                      value={t.status}
                      onChange={(e) => updateStatus(t.id, e.target.value as TicketStatus)}
                      className="h-8 rounded-md border bg-background px-2 text-xs"
                    >
                      {STATUSES.map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
              {!filtered.length && (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-muted-foreground">
                    Tidak ada ticket yang cocok dengan filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}

function Field({
  label,
  className,
  children,
}: {
  label: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={"space-y-2 " + (className ?? "")}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}
