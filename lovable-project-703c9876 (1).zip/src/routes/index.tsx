import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ShieldCheck, Lock, User as UserIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getSession, getToken, hydrate, login } from "@/lib/itsm-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DeancaITSM — Portal IT Service Management" },
      {
        name: "description",
        content:
          "Login portal DeancaITSM: ticketing, troubleshooting, manajemen aset, dan laporan IT support dalam satu dashboard.",
      },
      { property: "og:title", content: "DeancaITSM — Portal IT Service Management" },
      {
        property: "og:description",
        content: "Dashboard ITSM untuk ticketing, troubleshooting, aset, dan laporan IT support.",
      },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!getToken()) return;
    void hydrate(true).then(() => {
      if (getSession()) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    const result = await login(username, password);
    setLoading(false);
    if (!result.ok) {
      setError(result.error ?? "Login gagal.");
      return;
    }
    navigate({ to: "/dashboard", replace: true });
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-sidebar p-12 text-sidebar-foreground lg:flex">
        <div className="flex items-center gap-3">
          <div className="flex size-11 items-center justify-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground">
            <ShieldCheck className="size-6" />
          </div>
          <div>
            <p className="text-lg font-semibold">DeancaITSM</p>
            <p className="text-xs text-sidebar-foreground/70">IT Service Management Portal</p>
          </div>
        </div>
        <div className="max-w-md space-y-4">
          <h2 className="text-3xl font-semibold leading-tight">
            Kelola IT support, infrastruktur, dan laporan dalam satu portal.
          </h2>
          <ul className="space-y-2 text-sm text-sidebar-foreground/80">
            <li>• Ticketing incident & service request</li>
            <li>• Log troubleshooting dan knowledge base</li>
            <li>• Aset dengan status, lokasi, dan riwayat perubahan</li>
            <li>• Laporan siap cetak PDF, export CSV/Excel & Google Drive</li>
          </ul>
        </div>
        <p className="text-xs text-sidebar-foreground/60">
          © {new Date().getFullYear()} DeancaITSM. Internal IT Operations.
        </p>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="panel w-full max-w-md p-8">
          <h1 className="text-2xl font-semibold">Masuk ke portal</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Gunakan kredensial IT Anda untuk melanjutkan.
          </p>

          <form className="mt-6 space-y-4" onSubmit={submit}>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="relative">
                <UserIcon className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="username"
                  className="pl-9"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  autoComplete="username"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  className="pl-9"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  required
                />
              </div>
            </div>

            {error && (
              <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Memproses…" : "Masuk"}
            </Button>
          </form>

          <p className="mt-6 text-xs text-muted-foreground">
            Lupa kredensial? Hubungi administrator IT internal Anda.
          </p>
        </div>
      </div>
    </div>
  );
}
