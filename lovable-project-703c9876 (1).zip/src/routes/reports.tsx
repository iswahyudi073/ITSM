import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Printer, FileSpreadsheet, HardDriveUpload } from "lucide-react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import {
  downloadCSV,
  formatDate,
  getAssets,
  getTickets,
  getTroubles,
  uploadReportToDrive,
} from "@/lib/itsm-store";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Laporan IT Support & Infrastruktur — DeancaITSM" },
      {
        name: "description",
        content:
          "Laporan periodik ticket, troubleshooting, dan aset terdampak siap cetak PDF, export CSV untuk Excel, serta upload ke Google Drive.",
      },
      { property: "og:title", content: "Laporan IT Support & Infrastruktur — DeancaITSM" },
      {
        property: "og:description",
        content: "Rekap ticket, troubleshooting, dan aset terdampak dalam satu laporan.",
      },
    ],
  }),
  component: ReportsPage,
});

const today = () => new Date().toISOString().slice(0, 10);

function ReportsPage() {
  const { session } = useRequireAuth();
  useStoreVersion();
  const [from, setFrom] = useState("");
  const [driveMsg, setDriveMsg] = useState("");
  const [driveBusy, setDriveBusy] = useState(false);
  const [to, setTo] = useState("");

  const tickets = getTickets();
  const troubles = getTroubles();
  const assets = getAssets();

  const inRange = (iso: string) => {
    const d = iso.slice(0, 10);
    if (from && d < from) return false;
    if (to && d > to) return false;
    return true;
  };

  const ticketRows = useMemo(
    () => tickets.filter((t) => inRange(t.createdAt)),
    [tickets, from, to],
  );
  const troubleRows = useMemo(
    () => troubles.filter((t) => inRange(t.createdAt)),
    [troubles, from, to],
  );

  if (!session) return null;

  const impactedIds = new Set(
    [...ticketRows.map((t) => t.assetId), ...troubleRows.map((t) => t.assetId)].filter(Boolean),
  );
  const impactedAssets = assets.filter((a) => impactedIds.has(a.id));

  const summary = [
    { label: "Total ticket", value: ticketRows.length },
    {
      label: "Ticket aktif",
      value: ticketRows.filter((t) => !["Resolved", "Closed"].includes(t.status)).length,
    },
    { label: "Prioritas tinggi", value: ticketRows.filter((t) => t.priority === "High").length },
    { label: "Log troubleshooting", value: troubleRows.length },
    { label: "Aset terdampak", value: impactedAssets.length },
  ];

  const exportTickets = () =>
    downloadCSV(
      `laporan-ticket-${today()}.csv`,
      ticketRows.map((t) => ({
        "ID Ticket": t.id,
        Masalah: t.title,
        Tipe: t.type,
        Kategori: t.category,
        Prioritas: t.priority,
        Status: t.status,
        Requester: t.requester,
        Teknisi: t.assignee,
        "Aset Terdampak": t.assetId || "-",
        Dibuat: formatDate(t.createdAt),
        Diperbarui: formatDate(t.updatedAt),
      })),
    );

  const exportTroubles = () =>
    downloadCSV(
      `laporan-troubleshooting-${today()}.csv`,
      troubleRows.map((t) => ({
        "ID Log": t.id,
        "ID Ticket": t.ticketId || "-",
        "ID Aset": t.assetId || "-",
        Masalah: t.problem,
        "Akar Penyebab": t.rootCause,
        Tindakan: t.action,
        Hasil: t.result,
        Teknisi: t.handledBy,
        Tanggal: formatDate(t.createdAt),
      })),
    );

  const uploadToDrive = async () => {
    setDriveBusy(true);
    setDriveMsg("Mengunggah laporan ke Google Drive…");
    const res = await uploadReportToDrive(`laporan-ticket-${today()}.xlsx`, ticketRows.map((t) => ({
      "ID Ticket": t.id,
      Masalah: t.title,
      Tipe: t.type,
      Kategori: t.category,
      Prioritas: t.priority,
      Status: t.status,
      Requester: t.requester,
      Teknisi: t.assignee,
      "Aset Terdampak": t.assetId || "-",
      Dibuat: formatDate(t.createdAt),
      Diperbarui: formatDate(t.updatedAt),
    })));
    setDriveBusy(false);
    setDriveMsg(
      res.ok
        ? `Laporan berhasil diunggah ke Google Drive.${res.link ? ` Buka: ${res.link}` : ""}`
        : (res.error ?? "Unggahan ke Google Drive gagal."),
    );
  };

  const exportAssets = () =>
    downloadCSV(
      `laporan-aset-terdampak-${today()}.csv`,
      impactedAssets.map((a) => ({
        "ID Aset": a.id,
        Nama: a.name,
        Tipe: a.type,
        Pemilik: a.owner,
        Lokasi: a.location,
        Status: a.status,
        "Serial Number": a.serial,
      })),
    );

  return (
    <AppShell
      session={session}
      title="Laporan"
      description="Rekap ticket, troubleshooting, dan aset terdampak"
      actions={
        <>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="size-4" /> Print PDF
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => void uploadToDrive()}
            disabled={driveBusy}
          >
            <HardDriveUpload className="size-4" /> Google Drive
          </Button>
        </>
      }
    >
      {driveMsg && (
        <p className="no-print rounded-lg bg-muted px-4 py-3 text-sm break-words">{driveMsg}</p>
      )}

      <div className="no-print panel flex flex-wrap items-end gap-4 p-5">
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Dari tanggal</p>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Sampai tanggal</p>
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
        <Button
          variant="ghost"
          onClick={() => {
            setFrom("");
            setTo("");
          }}
        >
          Reset filter
        </Button>
        <div className="ml-auto flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={exportTickets}>
            <FileSpreadsheet className="size-4" /> CSV Ticket
          </Button>
          <Button variant="outline" size="sm" onClick={exportTroubles}>
            <FileSpreadsheet className="size-4" /> CSV Troubleshooting
          </Button>
          <Button variant="outline" size="sm" onClick={exportAssets}>
            <FileSpreadsheet className="size-4" /> CSV Aset
          </Button>
        </div>
      </div>

      <div className="print-area space-y-6">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          {summary.map((s) => (
            <div key={s.label} className="panel p-5">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="mt-1 text-2xl font-semibold">{s.value}</p>
            </div>
          ))}
        </div>

        <section className="panel overflow-x-auto">
          <h2 className="border-b px-4 py-3 text-sm font-semibold">Laporan Ticket</h2>
          <table className="w-full min-w-[860px] text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Masalah</th>
                <th className="px-4 py-3">Tipe</th>
                <th className="px-4 py-3">Prioritas</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Aset</th>
                <th className="px-4 py-3">Dibuat</th>
              </tr>
            </thead>
            <tbody>
              {ticketRows.map((t) => (
                <tr key={t.id} className="border-t">
                  <td className="px-4 py-3 font-mono text-xs">{t.id}</td>
                  <td className="px-4 py-3">{t.title}</td>
                  <td className="px-4 py-3">{t.type}</td>
                  <td className="px-4 py-3">
                    <StatusPill value={t.priority} />
                  </td>
                  <td className="px-4 py-3">
                    <StatusPill value={t.status} />
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">{t.assetId || "-"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{formatDate(t.createdAt)}</td>
                </tr>
              ))}
              {!ticketRows.length && (
                <tr>
                  <td className="px-4 py-8 text-center text-muted-foreground" colSpan={7}>
                    Tidak ada ticket pada periode ini.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </section>

        <section className="panel overflow-x-auto">
          <h2 className="border-b px-4 py-3 text-sm font-semibold">Laporan Troubleshooting</h2>
          <table className="w-full min-w-[860px] text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Masalah</th>
                <th className="px-4 py-3">Akar penyebab</th>
                <th className="px-4 py-3">Tindakan</th>
                <th className="px-4 py-3">Hasil</th>
                <th className="px-4 py-3">Tanggal</th>
              </tr>
            </thead>
            <tbody>
              {troubleRows.map((t) => (
                <tr key={t.id} className="border-t align-top">
                  <td className="px-4 py-3 font-mono text-xs">{t.id}</td>
                  <td className="px-4 py-3">{t.problem}</td>
                  <td className="px-4 py-3 text-muted-foreground">{t.rootCause}</td>
                  <td className="px-4 py-3 text-muted-foreground">{t.action}</td>
                  <td className="px-4 py-3">
                    <StatusPill value={t.result} />
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{formatDate(t.createdAt)}</td>
                </tr>
              ))}
              {!troubleRows.length && (
                <tr>
                  <td className="px-4 py-8 text-center text-muted-foreground" colSpan={6}>
                    Tidak ada log troubleshooting pada periode ini.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </section>

        <section className="panel overflow-x-auto">
          <h2 className="border-b px-4 py-3 text-sm font-semibold">Aset Terdampak</h2>
          <table className="w-full min-w-[720px] text-sm">
            <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Nama</th>
                <th className="px-4 py-3">Tipe</th>
                <th className="px-4 py-3">Lokasi</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {impactedAssets.map((a) => (
                <tr key={a.id} className="border-t">
                  <td className="px-4 py-3 font-mono text-xs">{a.id}</td>
                  <td className="px-4 py-3">{a.name}</td>
                  <td className="px-4 py-3">{a.type}</td>
                  <td className="px-4 py-3 text-muted-foreground">{a.location}</td>
                  <td className="px-4 py-3">
                    <StatusPill value={a.status} />
                  </td>
                </tr>
              ))}
              {!impactedAssets.length && (
                <tr>
                  <td className="px-4 py-8 text-center text-muted-foreground" colSpan={5}>
                    Tidak ada aset terdampak pada periode ini.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </section>
      </div>
    </AppShell>
  );
}
