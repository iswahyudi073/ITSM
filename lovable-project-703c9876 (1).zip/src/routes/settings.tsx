import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Globe, HardDrive, Mail, Plus, Save, Trash2, ShieldAlert } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useRequireAuth } from "@/hooks/use-itsm";
import {
  DEFAULT_SETTINGS,
  loadSettings,
  saveSettings,
  type AdminSettings,
  type DomainEntry,
} from "@/lib/itsm-store";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Pengaturan Admin — DeancaITSM" },
      {
        name: "description",
        content:
          "Kelola daftar domain resmi, koneksi Google Drive, dan konfigurasi email reset password DeancaITSM dari satu halaman administrator.",
      },
      { property: "og:title", content: "Pengaturan Admin — DeancaITSM" },
      {
        property: "og:description",
        content:
          "Kelola domain, Google Drive, dan email reset password DeancaITSM dari satu halaman administrator.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { session } = useRequireAuth();
  const [settings, setSettings] = useState<AdminSettings>(DEFAULT_SETTINGS);
  const [driveConnected, setDriveConnected] = useState(false);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [newDomain, setNewDomain] = useState<DomainEntry>({
    domain: "",
    note: "",
    allowSignup: true,
  });

  useEffect(() => {
    let alive = true;
    void loadSettings()
      .then((res) => {
        if (!alive) return;
        setSettings(res.settings);
        setDriveConnected(res.driveConnected);
      })
      .catch((e: unknown) => {
        if (alive) setError(e instanceof Error ? e.message : "Gagal memuat pengaturan.");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  if (!session) return null;
  const isAdmin = session.role === "admin";

  const persist = async (key: "domains" | "drive" | "email", value: unknown) => {
    setNotice("");
    setError("");
    const res = await saveSettings(key, value);
    if (!res.ok) {
      setError(res.error ?? "Gagal menyimpan pengaturan.");
      return;
    }
    setNotice("Pengaturan berhasil disimpan.");
  };

  const addDomain = async () => {
    const domain = newDomain.domain.trim().toLowerCase().replace(/^@/, "");
    if (!domain || !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(domain)) {
      setError("Format domain tidak valid, contoh: perusahaan.co.id");
      return;
    }
    if (settings.domains.items.some((d) => d.domain === domain)) {
      setError("Domain sudah terdaftar.");
      return;
    }
    const items = [...settings.domains.items, { ...newDomain, domain }];
    setSettings({ ...settings, domains: { items } });
    setNewDomain({ domain: "", note: "", allowSignup: true });
    await persist("domains", { items });
  };

  const updateDomain = async (index: number, patch: Partial<DomainEntry>) => {
    const items = settings.domains.items.map((d, i) => (i === index ? { ...d, ...patch } : d));
    setSettings({ ...settings, domains: { items } });
    await persist("domains", { items });
  };

  const removeDomain = async (index: number) => {
    const items = settings.domains.items.filter((_, i) => i !== index);
    setSettings({ ...settings, domains: { items } });
    await persist("domains", { items });
  };

  return (
    <AppShell
      session={session}
      title="Pengaturan"
      description="Domain resmi, koneksi Google Drive, dan email reset password"
    >
      {!isAdmin && (
        <div className="flex items-center gap-2 rounded-lg border border-warning/40 bg-warning/10 px-4 py-3 text-sm">
          <ShieldAlert className="size-4" />
          Hanya administrator yang dapat menyimpan perubahan. Anda hanya dapat melihat.
        </div>
      )}
      {notice && (
        <p className="rounded-lg bg-success/10 px-4 py-3 text-sm text-success">{notice}</p>
      )}
      {error && (
        <p className="rounded-lg bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</p>
      )}
      {loading && <p className="text-sm text-muted-foreground">Memuat pengaturan…</p>}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="size-4" /> Daftar Domain
          </CardTitle>
          <CardDescription>
            Domain email resmi organisasi. Domain yang diizinkan mendaftar dapat dipakai pengguna
            baru saat membuat akun.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-[1fr_1fr_auto_auto] md:items-end">
            <div className="space-y-1.5">
              <Label htmlFor="domain">Domain</Label>
              <Input
                id="domain"
                placeholder="perusahaan.co.id"
                value={newDomain.domain}
                onChange={(e) => setNewDomain({ ...newDomain, domain: e.target.value })}
                disabled={!isAdmin}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="domain-note">Keterangan</Label>
              <Input
                id="domain-note"
                placeholder="Kantor pusat"
                value={newDomain.note}
                onChange={(e) => setNewDomain({ ...newDomain, note: e.target.value })}
                disabled={!isAdmin}
              />
            </div>
            <div className="flex items-center gap-2 pb-2">
              <Switch
                id="domain-signup"
                checked={newDomain.allowSignup}
                onCheckedChange={(v) => setNewDomain({ ...newDomain, allowSignup: v })}
                disabled={!isAdmin}
              />
              <Label htmlFor="domain-signup">Boleh daftar</Label>
            </div>
            <Button onClick={() => void addDomain()} disabled={!isAdmin}>
              <Plus className="size-4" /> Tambah
            </Button>
          </div>

          {settings.domains.items.length === 0 ? (
            <p className="text-sm text-muted-foreground">Belum ada domain terdaftar.</p>
          ) : (
            <div className="divide-y rounded-lg border">
              {settings.domains.items.map((d, i) => (
                <div
                  key={d.domain}
                  className="flex flex-wrap items-center gap-3 px-4 py-3 text-sm"
                >
                  <span className="font-medium">@{d.domain}</span>
                  <span className="text-muted-foreground">{d.note || "—"}</span>
                  <div className="ml-auto flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={d.allowSignup}
                        onCheckedChange={(v) => void updateDomain(i, { allowSignup: v })}
                        disabled={!isAdmin}
                      />
                      <span className="text-muted-foreground">Boleh daftar</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => void removeDomain(i)}
                      disabled={!isAdmin}
                      aria-label={`Hapus domain ${d.domain}`}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="size-4" /> Koneksi Google Drive
          </CardTitle>
          <CardDescription>
            Tujuan penyimpanan file laporan yang diunggah dari halaman Laporan.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm">
            Status koneksi:{" "}
            <span className={driveConnected ? "font-medium text-success" : "font-medium text-destructive"}>
              {driveConnected ? "Terhubung" : "Belum terhubung"}
            </span>
            {!driveConnected && (
              <span className="text-muted-foreground">
                {" "}
                — hubungkan akun Google Drive terlebih dahulu agar unggahan laporan berjalan.
              </span>
            )}
          </p>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="folder-name">Nama folder tujuan</Label>
              <Input
                id="folder-name"
                placeholder="Laporan IT 2026"
                value={settings.drive.folderName}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    drive: { ...settings.drive, folderName: e.target.value },
                  })
                }
                disabled={!isAdmin}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="folder-id">ID folder Google Drive</Label>
              <Input
                id="folder-id"
                placeholder="1AbCdEf..."
                value={settings.drive.folderId}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    drive: { ...settings.drive, folderId: e.target.value },
                  })
                }
                disabled={!isAdmin}
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              id="auto-upload"
              checked={settings.drive.autoUpload}
              onCheckedChange={(v) =>
                setSettings({ ...settings, drive: { ...settings.drive, autoUpload: v } })
              }
              disabled={!isAdmin}
            />
            <Label htmlFor="auto-upload">Unggah otomatis setiap laporan diekspor</Label>
          </div>
          <Button onClick={() => void persist("drive", settings.drive)} disabled={!isAdmin}>
            <Save className="size-4" /> Simpan koneksi Drive
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="size-4" /> Email Reset Password
          </CardTitle>
          <CardDescription>
            Pengirim dan isi pesan yang dikirim saat pengguna meminta reset password. Gunakan
            {" {{nama}}"}, {"{{link}}"}, dan {"{{menit}}"} sebagai variabel.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <Switch
              id="email-enabled"
              checked={settings.email.enabled}
              onCheckedChange={(v) =>
                setSettings({ ...settings, email: { ...settings.email, enabled: v } })
              }
              disabled={!isAdmin}
            />
            <Label htmlFor="email-enabled">Aktifkan pengiriman email reset password</Label>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="sender-name">Nama pengirim</Label>
              <Input
                id="sender-name"
                value={settings.email.senderName}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    email: { ...settings.email, senderName: e.target.value },
                  })
                }
                disabled={!isAdmin}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sender-email">Email pengirim</Label>
              <Input
                id="sender-email"
                type="email"
                placeholder="it-support@perusahaan.co.id"
                value={settings.email.senderEmail}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    email: { ...settings.email, senderEmail: e.target.value },
                  })
                }
                disabled={!isAdmin}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reply-to">Balas ke</Label>
              <Input
                id="reply-to"
                type="email"
                placeholder="helpdesk@perusahaan.co.id"
                value={settings.email.replyTo}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    email: { ...settings.email, replyTo: e.target.value },
                  })
                }
                disabled={!isAdmin}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="expiry">Masa berlaku tautan (menit)</Label>
              <Input
                id="expiry"
                type="number"
                min={5}
                max={1440}
                value={settings.email.linkExpiryMinutes}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    email: {
                      ...settings.email,
                      linkExpiryMinutes: Number(e.target.value) || 30,
                    },
                  })
                }
                disabled={!isAdmin}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="subject">Judul email</Label>
            <Input
              id="subject"
              value={settings.email.subject}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  email: { ...settings.email, subject: e.target.value },
                })
              }
              disabled={!isAdmin}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="body">Isi email</Label>
            <Textarea
              id="body"
              rows={8}
              value={settings.email.body}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  email: { ...settings.email, body: e.target.value },
                })
              }
              disabled={!isAdmin}
            />
          </div>
          <Button onClick={() => void persist("email", settings.email)} disabled={!isAdmin}>
            <Save className="size-4" /> Simpan konfigurasi email
          </Button>
        </CardContent>
      </Card>
    </AppShell>
  );
}
