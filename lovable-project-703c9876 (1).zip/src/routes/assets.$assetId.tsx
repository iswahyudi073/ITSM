import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { ArrowLeft, Printer } from "lucide-react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import { formatDate, getAssets, getHistory, getTickets, getTroubles } from "@/lib/itsm-store";

export const Route = createFileRoute("/assets/$assetId")({
  head: () => ({
    meta: [
      { title: "Riwayat Perubahan Aset — DeancaITSM" },
      {
        name: "description",
        content:
          "Audit trail aset IT: siapa yang mengubah data, kapan perubahan dilakukan, serta ticket dan troubleshooting terkait.",
      },
      { property: "og:title", content: "Riwayat Perubahan Aset — DeancaITSM" },
      {
        property: "og:description",
        content: "Audit trail perubahan aset beserta ticket dan troubleshooting terkait.",
      },
    ],
  }),
  component: AssetHistoryPage,
});

function AssetHistoryPage() {
  const { session } = useRequireAuth();
  useStoreVersion();
  const { assetId } = useParams({ from: "/assets/$assetId" });
  if (!session) return null;

  const asset = getAssets().find((a) => a.id === assetId);
  const history = getHistory().filter((h) => h.assetId === assetId);
  const tickets = getTickets().filter((t) => t.assetId === assetId);
  const troubles = getTroubles().filter((t) => t.assetId === assetId);

  return (
    <AppShell
      session={session}
      title={asset ? `${asset.id} — ${asset.name}` : "Aset tidak ditemukan"}
      description="Riwayat perubahan & keterkaitan aset"
      actions={
        <>
          <Button variant="outline" size="sm" asChild>
            <Link to="/assets">
              <ArrowLeft className="size-4" /> Kembali
            </Link>
          </Button>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="size-4" /> Print / PDF
          </Button>
        </>
      }
    >
      {!asset ? (
        <div className="panel p-8 text-center text-muted-foreground">
          Aset dengan ID {assetId} tidak ditemukan.
        </div>
      ) : (
        <>
          <div className="panel grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-4">
            <Info label="Tipe" value={asset.type} />
            <Info label="Serial Number" value={asset.serial} />
            <Info label="Pemilik" value={asset.owner} />
            <Info label="Lokasi" value={asset.location} />
            <div>
              <p className="text-xs uppercase text-muted-foreground">Status</p>
              <div className="mt-1">
                <StatusPill value={asset.status} />
              </div>
            </div>
            <Info label="Dibuat" value={formatDate(asset.createdAt)} />
            <Info label="Terakhir Diubah" value={formatDate(asset.updatedAt)} />
          </div>

          <div className="panel print-area overflow-hidden">
            <div className="border-b px-5 py-4">
              <h2 className="text-sm font-semibold">Riwayat Perubahan (Audit Trail)</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">Waktu</th>
                    <th className="px-4 py-3">Aksi</th>
                    <th className="px-4 py-3">Perubahan</th>
                    <th className="px-4 py-3">Diubah Oleh</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((h) => (
                    <tr key={h.id} className="border-t">
                      <td className="px-4 py-3 whitespace-nowrap">{formatDate(h.changedAt)}</td>
                      <td className="px-4 py-3">{h.action}</td>
                      <td className="px-4 py-3 text-muted-foreground">{h.changes}</td>
                      <td className="px-4 py-3">{h.changedBy}</td>
                    </tr>
                  ))}
                  {!history.length && (
                    <tr>
                      <td colSpan={4} className="px-4 py-10 text-center text-muted-foreground">
                        Belum ada perubahan tercatat untuk aset ini.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="panel p-5">
              <h2 className="text-sm font-semibold">Ticket Terkait ({tickets.length})</h2>
              <ul className="mt-3 space-y-3">
                {tickets.map((t) => (
                  <li key={t.id} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-xs">{t.id}</span>
                      <StatusPill value={t.status} />
                    </div>
                    <p className="mt-1 text-sm font-medium">{t.title}</p>
                    <p className="text-xs text-muted-foreground">Requester: {t.requester}</p>
                  </li>
                ))}
                {!tickets.length && (
                  <li className="text-sm text-muted-foreground">Tidak ada ticket terkait.</li>
                )}
              </ul>
            </div>

            <div className="panel p-5">
              <h2 className="text-sm font-semibold">Troubleshooting Terkait ({troubles.length})</h2>
              <ul className="mt-3 space-y-3">
                {troubles.map((t) => (
                  <li key={t.id} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-xs">{t.id}</span>
                      <StatusPill value={t.result} />
                    </div>
                    <p className="mt-1 text-sm font-medium">{t.problem}</p>
                    <p className="text-xs text-muted-foreground">Penanganan: {t.action}</p>
                    <p className="text-xs text-muted-foreground">
                      Oleh {t.handledBy} · {formatDate(t.createdAt)}
                    </p>
                  </li>
                ))}
                {!troubles.length && (
                  <li className="text-sm text-muted-foreground">Belum ada log troubleshooting.</li>
                )}
              </ul>
            </div>
          </div>
        </>
      )}
    </AppShell>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs uppercase text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  );
}
