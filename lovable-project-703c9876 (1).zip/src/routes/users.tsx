import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus, ShieldAlert, KeyRound, Power } from "lucide-react";
import { AppShell, StatusPill } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRequireAuth, useStoreVersion } from "@/hooks/use-itsm";
import {
  createUser,
  formatDate,
  getUsers,
  nextId,
  setUserPassword,
  updateUser,
  validatePassword,
  PASSWORD_RULES,
  type Role,
} from "@/lib/itsm-store";

export const Route = createFileRoute("/users")({
  head: () => ({
    meta: [
      { title: "Manajemen User & Hak Akses — DeancaITSM" },
      {
        name: "description",
        content:
          "Kelola akun admin, technician, requester, dan user: tambah akun, atur status aktif, serta reset password dengan kebijakan kompleks.",
      },
      { property: "og:title", content: "Manajemen User & Hak Akses — DeancaITSM" },
      {
        property: "og:description",
        content: "Kelola peran, status akun, dan reset password pengguna ITSM.",
      },
    ],
  }),
  component: UsersPage,
});

const ROLES: Role[] = ["admin", "technician", "requester", "user"];

function UsersPage() {
  const { session } = useRequireAuth();
  const { refresh } = useStoreVersion();
  const [query, setQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [resetFor, setResetFor] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [resetEmail, setResetEmail] = useState<{
    to: string;
    subject: string;
    body: string;
  } | null>(null);

  const users = getUsers();
  const filtered = useMemo(
    () =>
      users.filter((u) =>
        [u.id, u.username, u.fullName, u.email, u.role]
          .join(" ")
          .toLowerCase()
          .includes(query.toLowerCase()),
      ),
    [users, query],
  );

  if (!session) return null;

  const isAdmin = session.role === "admin";
  if (!isAdmin) {
    return (
      <AppShell session={session} title="User & Akses" description="Akses terbatas">
        <div className="panel flex items-center gap-3 p-6 text-sm">
          <ShieldAlert className="size-5 text-destructive" />
          Hanya administrator yang dapat mengelola pengguna dan hak akses.
        </div>
      </AppShell>
    );
  }

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const username = String(fd.get("username") || "")
      .trim()
      .toLowerCase();
    const password = String(fd.get("password") || "");
    const list = getUsers();
    if (list.some((u) => u.username.toLowerCase() === username)) {
      setError("Username sudah digunakan.");
      return;
    }
    const issues = validatePassword(password);
    if (issues.length) {
      setError(`Password belum memenuhi: ${issues.join(", ")}.`);
      return;
    }
    const res = await createUser({
      id: nextId(
        "USR",
        list.map((u) => u.id),
      ),
      username,
      fullName: String(fd.get("fullName") || username),
      email: String(fd.get("email") || ""),
      role: String(fd.get("role") || "user") as Role,
      password,
    });
    if (!res.ok) {
      setError(res.error ?? "Gagal membuat user.");
      return;
    }
    setError("");
    setNotice(`Akun ${username} berhasil dibuat.`);
    setShowForm(false);
    refresh();
  };

  const toggleStatus = async (id: string) => {
    const target = getUsers().find((u) => u.id === id);
    if (!target) return;
    const res = await updateUser(id, {
      status: target.status === "Active" ? "Inactive" : "Active",
    });
    if (!res.ok) setError(res.error ?? "Gagal memperbarui status.");
    refresh();
  };

  const changeRole = async (id: string, role: Role) => {
    const res = await updateUser(id, { role });
    if (!res.ok) setError(res.error ?? "Gagal memperbarui peran.");
    refresh();
  };

  const applyReset = async (id: string) => {
    const issues = validatePassword(newPassword);
    if (issues.length) {
      setError(`Password belum memenuhi: ${issues.join(", ")}.`);
      return;
    }
    const res = await setUserPassword({ targetUserId: id, newPassword });
    if (!res.ok) {
      setError(res.error ?? "Gagal mereset password.");
      return;
    }
    setError("");
    setResetEmail(res.email ?? null);
    setNotice(
      res.email
        ? `Password berhasil direset. Draf email siap dikirim ke ${res.email.to}.`
        : "Password berhasil direset.",
    );
    setResetFor(null);
    setNewPassword("");
    refresh();
  };

  return (
    <AppShell
      session={session}
      title="User & Akses"
      description="Kelola akun, peran, dan status pengguna"
      actions={
        <Button size="sm" onClick={() => setShowForm((v) => !v)}>
          <Plus className="size-4" /> Tambah User
        </Button>
      }
    >
      {resetEmail && (
        <div className="panel space-y-2 p-5 text-sm">
          <p className="font-medium">Draf email reset password</p>
          <p className="text-muted-foreground">Kepada: {resetEmail.to}</p>
          <p className="text-muted-foreground">Judul: {resetEmail.subject}</p>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted p-3">{resetEmail.body}</pre>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                void navigator.clipboard.writeText(resetEmail.body);
                setNotice("Isi email disalin.");
              }}
            >
              Salin isi email
            </Button>
            <Button
              size="sm"
              onClick={() => {
                window.location.href = `mailto:${resetEmail.to}?subject=${encodeURIComponent(
                  resetEmail.subject,
                )}&body=${encodeURIComponent(resetEmail.body)}`;
              }}
            >
              Kirim lewat email
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setResetEmail(null)}>
              Tutup
            </Button>
          </div>
        </div>
      )}

      {showForm && (
        <form className="panel space-y-4 p-5" onSubmit={(e) => void submit(e)}>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input id="username" name="username" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fullName">Nama lengkap</Label>
              <Input id="fullName" name="fullName" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Peran</Label>
              <select
                id="role"
                name="role"
                className="h-10 w-full rounded-md border bg-background px-3 text-sm"
              >
                {ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" name="password" type="password" required />
              <ul className="text-xs text-muted-foreground">
                {PASSWORD_RULES.map((r) => (
                  <li key={r.label}>• {r.label}</li>
                ))}
              </ul>
            </div>
          </div>
          <div className="flex gap-2">
            <Button type="submit">Simpan user</Button>
            <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>
              Batal
            </Button>
          </div>
        </form>
      )}

      {error && (
        <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>
      )}
      {notice && (
        <p className="rounded-md bg-success/10 px-3 py-2 text-sm text-success">{notice}</p>
      )}

      <Input
        placeholder="Cari user…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="max-w-sm"
      />

      <div className="panel overflow-x-auto">
        <table className="w-full min-w-[860px] text-sm">
          <thead className="bg-muted/60 text-left text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">ID</th>
              <th className="px-4 py-3">Username</th>
              <th className="px-4 py-3">Nama</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Peran</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Dibuat</th>
              <th className="px-4 py-3">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u) => (
              <tr key={u.id} className="border-t">
                <td className="px-4 py-3 font-mono text-xs">{u.id}</td>
                <td className="px-4 py-3 font-medium">{u.username}</td>
                <td className="px-4 py-3">{u.fullName}</td>
                <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                <td className="px-4 py-3">
                  <select
                    className="h-8 rounded-md border bg-background px-2 text-xs capitalize"
                    value={u.role}
                    onChange={(e) => void changeRole(u.id, e.target.value as Role)}
                  >
                    {ROLES.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-3">
                  <StatusPill value={u.status} />
                </td>
                <td className="px-4 py-3 text-muted-foreground">{formatDate(u.createdAt)}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" variant="outline" onClick={() => void toggleStatus(u.id)}>
                      <Power className="size-3.5" />
                      {u.status === "Active" ? "Nonaktifkan" : "Aktifkan"}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setResetFor(resetFor === u.id ? null : u.id);
                        setNewPassword("");
                        setError("");
                      }}
                    >
                      <KeyRound className="size-3.5" /> Reset
                    </Button>
                  </div>
                  {resetFor === u.id && (
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <Input
                        type="password"
                        placeholder="Password baru"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="h-8 w-48"
                      />
                      <Button size="sm" onClick={() => void applyReset(u.id)}>
                        Simpan
                      </Button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
            {!filtered.length && (
              <tr>
                <td className="px-4 py-8 text-center text-muted-foreground" colSpan={8}>
                  Tidak ada user.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
