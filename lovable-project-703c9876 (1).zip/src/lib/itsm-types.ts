// DeancaITSM — shared domain types & pure helpers (client-safe)

export type Role = "admin" | "technician" | "requester" | "user";
export type UserStatus = "Active" | "Inactive";

export interface AppUser {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: Role;
  status: UserStatus;
  passwordHash: string;
  createdAt: string;
}

export type TicketType = "Incident" | "Service Request";
export type Priority = "High" | "Normal" | "Low";
export type TicketStatus = "Open" | "In Progress" | "Pending" | "Resolved" | "Closed";

export interface Ticket {
  id: string;
  title: string;
  description: string;
  type: TicketType;
  category: string;
  priority: Priority;
  status: TicketStatus;
  requester: string;
  assignee: string;
  assetId: string;
  createdAt: string;
  updatedAt: string;
}

export type AssetStatus = "In Use" | "In Stock" | "Maintenance" | "Retired";

export interface Asset {
  id: string;
  name: string;
  type: string;
  owner: string;
  location: string;
  status: AssetStatus;
  serial: string;
  createdAt: string;
  updatedAt: string;
}

export interface AssetHistory {
  id: string;
  assetId: string;
  action: string;
  changes: string;
  changedBy: string;
  changedAt: string;
}

export interface Troubleshoot {
  id: string;
  ticketId: string;
  assetId: string;
  problem: string;
  rootCause: string;
  action: string;
  result: "Resolved" | "Escalated" | "Monitoring";
  handledBy: string;
  createdAt: string;
}

export interface Session {
  userId: string;
  username: string;
  role: Role;
  fullName: string;
}

export interface ItsmSnapshot {
  session: Session;
  users: AppUser[];
  tickets: Ticket[];
  assets: Asset[];
  history: AssetHistory[];
  troubles: Troubleshoot[];
}

export const PASSWORD_RULES = [
  { label: "Minimal 10 karakter", test: (v: string) => v.length >= 10 },
  { label: "Mengandung huruf besar", test: (v: string) => /[A-Z]/.test(v) },
  { label: "Mengandung huruf kecil", test: (v: string) => /[a-z]/.test(v) },
  { label: "Mengandung angka", test: (v: string) => /[0-9]/.test(v) },
  { label: "Mengandung simbol", test: (v: string) => /[^A-Za-z0-9]/.test(v) },
];

export function validatePassword(v: string): string[] {
  return PASSWORD_RULES.filter((r) => !r.test(v)).map((r) => r.label);
}

export function nowISO() {
  return new Date().toISOString();
}

export function formatDate(iso: string) {
  if (!iso) return "-";
  return new Date(iso).toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function nextId(prefix: string, existing: string[], pad = 3) {
  const nums = existing
    .map((id) => parseInt(id.replace(/\D/g, ""), 10))
    .filter((n) => !Number.isNaN(n));
  const next = (nums.length ? Math.max(...nums) : 0) + 1;
  return `${prefix}-${String(next).padStart(pad, "0")}`;
}
