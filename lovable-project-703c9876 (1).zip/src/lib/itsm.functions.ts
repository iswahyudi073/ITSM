import { createServerFn } from "@tanstack/react-start";
import { createHash, randomBytes } from "node:crypto";
import type {
  AppUser,
  Asset,
  AssetHistory,
  ItsmSnapshot,
  Role,
  Session,
  Ticket,
  Troubleshoot,
} from "./itsm-types";

/* ---------- helpers ---------- */

function hash(password: string) {
  return createHash("sha256").update(`deancaitsm:${password}`).digest("hex");
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

type DbUser = {
  id: string;
  username: string;
  full_name: string;
  email: string;
  role: string;
  status: string;
  password_hash: string;
  created_at: string;
};

const toUser = (r: DbUser): AppUser => ({
  id: r.id,
  username: r.username,
  fullName: r.full_name,
  email: r.email,
  role: r.role as Role,
  status: r.status as AppUser["status"],
  passwordHash: "",
  createdAt: r.created_at,
});

async function resolveSession(token: string) {
  if (!token) throw new Error("Sesi tidak valid. Silakan login kembali.");
  const db = await admin();
  const { data: sess } = await db
    .from("app_sessions")
    .select("token,user_id,expires_at")
    .eq("token", token)
    .maybeSingle();
  if (!sess || new Date(sess.expires_at).getTime() < Date.now()) {
    throw new Error("Sesi berakhir. Silakan login kembali.");
  }
  const { data: user } = await db
    .from("app_users")
    .select("*")
    .eq("id", sess.user_id)
    .maybeSingle();
  if (!user || user.status !== "Active") throw new Error("Akun tidak aktif.");
  return { db, user: user as DbUser };
}

async function audit(
  db: Awaited<ReturnType<typeof admin>>,
  actor: DbUser,
  action: string,
  category: string,
  target: string,
  detail = "",
) {
  await db.from("audit_logs").insert({
    actor: actor.username,
    actor_role: actor.role,
    action,
    category,
    target,
    detail,
  });
}

/* ---------- auth ---------- */

export const itsmLogin = createServerFn({ method: "POST" })
  .inputValidator((d: { username: string; password: string }) => d)
  .handler(async ({ data }): Promise<{ ok: boolean; error?: string; token?: string }> => {
    const db = await admin();
    const { data: rows } = await db.from("app_users").select("*");
    const user = (rows ?? []).find(
      (u) => u.username.toLowerCase() === data.username.trim().toLowerCase(),
    ) as DbUser | undefined;
    if (!user) return { ok: false, error: "Username tidak ditemukan." };
    if (user.status !== "Active")
      return { ok: false, error: "Akun nonaktif. Hubungi administrator." };
    if (user.password_hash !== hash(data.password)) return { ok: false, error: "Password salah." };

    const token = randomBytes(32).toString("hex");
    await db.from("app_sessions").insert({ token, user_id: user.id });
    await audit(db, user, "Login", "auth", user.username);
    return { ok: true, token };
  });

export const itsmLogout = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const db = await admin();
    await db.from("app_sessions").delete().eq("token", data.token);
    return { ok: true };
  });

/* ---------- bootstrap ---------- */

export const itsmBootstrap = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }): Promise<ItsmSnapshot> => {
    const { db, user } = await resolveSession(data.token);
    const [users, tickets, assets, history, troubles] = await Promise.all([
      db.from("app_users").select("*").order("id"),
      db.from("tickets").select("*").order("created_at", { ascending: false }),
      db.from("assets").select("*").order("id"),
      db.from("asset_history").select("*").order("changed_at", { ascending: false }),
      db.from("troubleshoots").select("*").order("created_at", { ascending: false }),
    ]);

    const allUsers = ((users.data ?? []) as DbUser[]).map(toUser);
    const session: Session = {
      userId: user.id,
      username: user.username,
      role: user.role as Role,
      fullName: user.full_name,
    };

    return {
      session,
      users: user.role === "admin" ? allUsers : allUsers.filter((u) => u.id === user.id),
      tickets: (tickets.data ?? []).map((t) => ({
        id: t.id,
        title: t.title,
        description: t.description,
        type: t.type as Ticket["type"],
        category: t.category,
        priority: t.priority as Ticket["priority"],
        status: t.status as Ticket["status"],
        requester: t.requester,
        assignee: t.assignee,
        assetId: t.asset_id,
        createdAt: t.created_at,
        updatedAt: t.updated_at,
      })),
      assets: (assets.data ?? []).map((a) => ({
        id: a.id,
        name: a.name,
        type: a.type,
        owner: a.owner,
        location: a.location,
        status: a.status as Asset["status"],
        serial: a.serial,
        createdAt: a.created_at,
        updatedAt: a.updated_at,
      })),
      history: (history.data ?? []).map((h) => ({
        id: h.id,
        assetId: h.asset_id,
        action: h.action,
        changes: h.changes,
        changedBy: h.changed_by,
        changedAt: h.changed_at,
      })),
      troubles: (troubles.data ?? []).map((t) => ({
        id: t.id,
        ticketId: t.ticket_id,
        assetId: t.asset_id,
        problem: t.problem,
        rootCause: t.root_cause,
        action: t.action,
        result: t.result as Troubleshoot["result"],
        handledBy: t.handled_by,
        createdAt: t.created_at,
      })),
    };
  });

/* ---------- persistence ---------- */

type SyncPayload =
  | { table: "tickets"; rows: Ticket[] }
  | { table: "assets"; rows: Asset[] }
  | { table: "troubleshoots"; rows: Troubleshoot[] }
  | { table: "asset_history"; rows: AssetHistory[] };

export const itsmSync = createServerFn({ method: "POST" })
  .inputValidator((d: SyncPayload & { token: string }) => d)
  .handler(async ({ data }) => {
    const { db, user } = await resolveSession(data.token);
    if (user.role === "user" || user.role === "requester") {
      if (data.table !== "tickets")
        throw new Error("Anda tidak memiliki hak akses untuk data ini.");
    }

    let rows: Record<string, unknown>[] = [];
    if (data.table === "tickets") {
      rows = data.rows.map((t) => ({
        id: t.id,
        title: t.title,
        description: t.description,
        type: t.type,
        category: t.category,
        priority: t.priority,
        status: t.status,
        requester: t.requester,
        assignee: t.assignee,
        asset_id: t.assetId,
        created_at: t.createdAt,
        updated_at: t.updatedAt,
      }));
    } else if (data.table === "assets") {
      rows = data.rows.map((a) => ({
        id: a.id,
        name: a.name,
        type: a.type,
        owner: a.owner,
        location: a.location,
        status: a.status,
        serial: a.serial,
        created_at: a.createdAt,
        updated_at: a.updatedAt,
      }));
    } else if (data.table === "troubleshoots") {
      rows = data.rows.map((t) => ({
        id: t.id,
        ticket_id: t.ticketId,
        asset_id: t.assetId,
        problem: t.problem,
        root_cause: t.rootCause,
        action: t.action,
        result: t.result,
        handled_by: t.handledBy,
        created_at: t.createdAt,
      }));
    } else {
      rows = data.rows.map((h) => ({
        id: h.id,
        asset_id: h.assetId,
        action: h.action,
        changes: h.changes,
        changed_by: h.changedBy,
        changed_at: h.changedAt,
      }));
    }

    if (rows.length) {
      const { error } = await db.from(data.table).upsert(rows as never, { onConflict: "id" });
      if (error) throw new Error(error.message);
    }
    const keep = rows.map((r) => String(r["id"]));
    const del = db.from(data.table).delete();
    await (keep.length
      ? del.not("id", "in", `(${keep.map((k) => `"${k}"`).join(",")})`)
      : del.neq("id", "___none___"));

    await audit(db, user, "Simpan data", data.table, `${rows.length} baris`);
    return { ok: true };
  });

/* ---------- users ---------- */

export const itsmSaveUsers = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; rows: AppUser[] }) => d)
  .handler(async ({ data }) => {
    const { db, user } = await resolveSession(data.token);
    if (user.role !== "admin")
      throw new Error("Hanya administrator yang dapat mengelola pengguna.");
    const rows = data.rows.map((u) => ({
      id: u.id,
      username: u.username,
      full_name: u.fullName,
      email: u.email,
      role: u.role,
      status: u.status,
      created_at: u.createdAt,
    }));
    for (const r of rows) {
      const { error } = await db
        .from("app_users")
        .upsert({ ...r, password_hash: hash(randomBytes(16).toString("hex")) } as never, {
          onConflict: "id",
          ignoreDuplicates: false,
        });
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const itsmCreateUser = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      token: string;
      id: string;
      username: string;
      fullName: string;
      email: string;
      role: Role;
      password: string;
    }) => d,
  )
  .handler(async ({ data }) => {
    const { db, user } = await resolveSession(data.token);
    if (user.role !== "admin") throw new Error("Hanya administrator yang dapat menambah pengguna.");
    const { error } = await db.from("app_users").insert({
      id: data.id,
      username: data.username,
      full_name: data.fullName,
      email: data.email,
      role: data.role,
      status: "Active",
      password_hash: hash(data.password),
    });
    if (error) throw new Error(error.message);
    await audit(db, user, "Tambah pengguna", "users", data.username);
    return { ok: true };
  });

export const itsmUpdateUser = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; id: string; role?: Role; status?: string }) => d)
  .handler(async ({ data }) => {
    const { db, user } = await resolveSession(data.token);
    if (user.role !== "admin") throw new Error("Hanya administrator yang dapat mengubah pengguna.");
    const patch: { role?: string; status?: string } = {};
    if (data.role) patch.role = data.role;
    if (data.status) patch.status = data.status;
    const { error } = await db.from("app_users").update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    await audit(db, user, "Ubah pengguna", "users", data.id, JSON.stringify(patch));
    return { ok: true };
  });

export const itsmSetPassword = createServerFn({ method: "POST" })
  .inputValidator(
    (d: { token: string; targetUserId: string; newPassword: string; currentPassword?: string }) =>
      d,
  )
  .handler(async ({ data }) => {
    const { db, user } = await resolveSession(data.token);
    const isSelf = data.targetUserId === user.id;
    if (!isSelf && user.role !== "admin")
      throw new Error("Hanya administrator yang dapat mereset password pengguna lain.");
    if (isSelf) {
      if (user.password_hash !== hash(data.currentPassword ?? ""))
        return { ok: false, error: "Password saat ini salah." };
    }
    const { error } = await db
      .from("app_users")
      .update({ password_hash: hash(data.newPassword) })
      .eq("id", data.targetUserId);
    if (error) throw new Error(error.message);
    await audit(db, user, "Reset password", "auth", data.targetUserId);

    let email: { to: string; subject: string; body: string } | null = null;
    if (!isSelf) {
      const settings = await readSettings(db);
      const { data: target } = await db
        .from("app_users")
        .select("full_name,email")
        .eq("id", data.targetUserId)
        .maybeSingle();
      if (settings.email.enabled && target?.email) {
        const fill = (tpl: string) =>
          tpl
            .replaceAll("{{nama}}", target.full_name || target.email)
            .replaceAll("{{link}}", data.newPassword)
            .replaceAll("{{menit}}", String(settings.email.linkExpiryMinutes));
        email = {
          to: target.email,
          subject: fill(settings.email.subject),
          body: fill(settings.email.body),
        };
        await audit(db, user, "Menyiapkan email reset password", "auth", target.email);
      }
    }
    return { ok: true, email };
  });

/* ---------- Google Drive ---------- */

export const itsmUploadToDrive = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; filename: string; base64: string; mimeType: string }) => d)
  .handler(async ({ data }) => {
    const { db, user } = await resolveSession(data.token);
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const connectionKey = process.env["GOOGLE_DRIVE_API_KEY"];
    if (!lovableKey || !connectionKey) {
      return {
        ok: false,
        error:
          "Google Drive belum terhubung. Minta administrator menghubungkan akun Google Drive pada pengaturan integrasi.",
      };
    }

    const settings = await readSettings(db);
    const folderId = settings.drive.folderId.trim();
    const boundary = `deancaitsm${Date.now()}`;
    const metadata = JSON.stringify({
      name: data.filename,
      mimeType: data.mimeType,
      ...(folderId ? { parents: [folderId] } : {}),
    });
    const body =
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n` +
      `--${boundary}\r\nContent-Type: ${data.mimeType}\r\nContent-Transfer-Encoding: base64\r\n\r\n${data.base64}\r\n` +
      `--${boundary}--`;

    const res = await fetch(
      "https://connector-gateway.lovable.dev/google_drive/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${lovableKey}`,
          "X-Connection-Api-Key": connectionKey,
          "Content-Type": `multipart/related; boundary=${boundary}`,
        },
        body,
      },
    );
    const text = await res.text();
    if (!res.ok) {
      console.error(`Drive upload failed [${res.status}]: ${text}`);
      return { ok: false, error: `Upload Google Drive gagal [${res.status}]: ${text}` };
    }
    const file = JSON.parse(text) as { id: string; name: string; webViewLink?: string };
    await audit(db, user, "Upload laporan ke Google Drive", "report", data.filename);
    return {
      ok: true,
      link: file.webViewLink ?? `https://drive.google.com/file/d/${file.id}/view`,
    };
  });

/* ---------- pengaturan admin ---------- */

export type DomainEntry = { domain: string; note: string; allowSignup: boolean };
export type AdminSettings = {
  domains: { items: DomainEntry[] };
  drive: { folderId: string; folderName: string; autoUpload: boolean };
  email: {
    enabled: boolean;
    senderName: string;
    senderEmail: string;
    replyTo: string;
    subject: string;
    body: string;
    linkExpiryMinutes: number;
  };
};

export const DEFAULT_SETTINGS: AdminSettings = {
  domains: { items: [] },
  drive: { folderId: "", folderName: "", autoUpload: false },
  email: {
    enabled: false,
    senderName: "DeancaITSM Support",
    senderEmail: "",
    replyTo: "",
    subject: "Reset password akun DeancaITSM",
    body: "Halo {{nama}},\n\nKlik tautan berikut untuk mengatur ulang password Anda: {{link}}\nTautan berlaku {{menit}} menit.\n\nSalam,\nTim IT",
    linkExpiryMinutes: 30,
  },
};

async function readSettings(db: Awaited<ReturnType<typeof admin>>): Promise<AdminSettings> {
  const { data: rows } = await db.from("app_settings").select("key,value");
  const settings: AdminSettings = { ...DEFAULT_SETTINGS };
  for (const row of rows ?? []) {
    const key = row.key as keyof AdminSettings;
    if (key in settings) {
      settings[key] = {
        ...(DEFAULT_SETTINGS[key] as object),
        ...(row.value as object),
      } as never;
    }
  }
  return settings;
}

export const itsmGetSettings = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }): Promise<{ settings: AdminSettings; driveConnected: boolean }> => {
    const { db } = await resolveSession(data.token);
    const settings = await readSettings(db);
    const driveConnected = Boolean(
      process.env["LOVABLE_API_KEY"] && process.env["GOOGLE_DRIVE_API_KEY"],
    );
    return { settings, driveConnected };
  });

export const itsmSaveSettings = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; key: string; value: unknown }) => d)
  .handler(async ({ data }): Promise<{ ok: boolean; error?: string }> => {
    const { db, user } = await resolveSession(data.token);
    if (user.role !== "admin") return { ok: false, error: "Hanya administrator yang dapat mengubah pengaturan." };
    if (!["domains", "drive", "email"].includes(data.key))
      return { ok: false, error: "Pengaturan tidak dikenal." };
    const { error } = await db.from("app_settings").upsert(
      {
        key: data.key,
        value: data.value as never,
        updated_by: user.username,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "key" },
    );
    if (error) return { ok: false, error: error.message };
    await audit(db, user, "Mengubah pengaturan", "settings", data.key);
    return { ok: true };
  });
