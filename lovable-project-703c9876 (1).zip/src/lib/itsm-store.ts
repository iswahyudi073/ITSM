// DeancaITSM — client cache backed by the real database (server functions).

import * as XLSX from "xlsx";
import {
  itsmBootstrap,
  itsmCreateUser,
  itsmGetSettings,
  itsmLogin,
  itsmLogout,
  itsmSaveSettings,
  itsmSetPassword,
  itsmSync,
  itsmUpdateUser,
  itsmUploadToDrive,
} from "./itsm.functions";
import type {
  AppUser,
  Asset,
  AssetHistory,
  ItsmSnapshot,
  Role,
  Session,
  Ticket,
  Troubleshoot,
} from "./itsm-types";

export * from "./itsm-types";
export type { ItsmSnapshot };

const TOKEN_KEY = "deancaitsm.token";
const CACHE_KEY = "deancaitsm.cache";

const isBrowser = () => typeof window !== "undefined";

const emptyCache: Omit<ItsmSnapshot, "session"> & { session: Session | null } = {
  session: null,
  users: [],
  tickets: [],
  assets: [],
  history: [],
  troubles: [],
};

type Cache = typeof emptyCache;

function readCache(): Cache {
  if (!isBrowser()) return emptyCache;
  try {
    const raw = window.localStorage.getItem(CACHE_KEY);
    return raw ? { ...emptyCache, ...(JSON.parse(raw) as Cache) } : emptyCache;
  } catch {
    return emptyCache;
  }
}

function writeCache(next: Cache) {
  if (!isBrowser()) return;
  window.localStorage.setItem(CACHE_KEY, JSON.stringify(next));
  window.dispatchEvent(new CustomEvent("deancaitsm:changed"));
}

function patchCache(patch: Partial<Cache>) {
  writeCache({ ...readCache(), ...patch });
}

export function getToken(): string {
  if (!isBrowser()) return "";
  return window.localStorage.getItem(TOKEN_KEY) ?? "";
}

function setToken(token: string | null) {
  if (!isBrowser()) return;
  if (token) window.localStorage.setItem(TOKEN_KEY, token);
  else window.localStorage.removeItem(TOKEN_KEY);
}

/* ---------- session & hydration ---------- */

export function getSession(): Session | null {
  return readCache().session;
}

let hydrating: Promise<void> | null = null;

/** Loads the latest snapshot from the database into the local cache. */
export async function hydrate(force = false): Promise<void> {
  if (!isBrowser()) return;
  const token = getToken();
  if (!token) {
    if (readCache().session) writeCache(emptyCache);
    return;
  }
  if (hydrating && !force) return hydrating;
  hydrating = (async () => {
    try {
      const snap = await itsmBootstrap({ data: { token } });
      writeCache(snap);
    } catch {
      setToken(null);
      writeCache(emptyCache);
    } finally {
      hydrating = null;
    }
  })();
  return hydrating;
}

/** Kept for backwards compatibility with existing pages. */
export function ensureSeed() {
  void hydrate();
}

export async function login(
  username: string,
  password: string,
): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await itsmLogin({ data: { username, password } });
    if (!res.ok || !res.token) return { ok: false, error: res.error ?? "Login gagal." };
    setToken(res.token);
    await hydrate(true);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Login gagal." };
  }
}

export function logout() {
  const token = getToken();
  setToken(null);
  writeCache(emptyCache);
  if (token) void itsmLogout({ data: { token } }).catch(() => undefined);
}

/* ---------- reads ---------- */

export const getUsers = () => readCache().users;
export const getTickets = () => readCache().tickets;
export const getAssets = () => readCache().assets;
export const getHistory = () => readCache().history;
export const getTroubles = () => readCache().troubles;

/* ---------- writes (optimistic cache + server sync) ---------- */

function sync(table: "tickets" | "assets" | "troubleshoots" | "asset_history", rows: unknown[]) {
  const token = getToken();
  if (!token) return;
  void Promise.resolve(itsmSync({ data: { token, table, rows } as never })).catch((e: unknown) => {
    console.error("[DeancaITSM] gagal menyimpan ke database", e);
  });
}

export function saveTickets(rows: Ticket[]) {
  patchCache({ tickets: rows });
  sync("tickets", rows);
}

export function saveAssets(rows: Asset[]) {
  patchCache({ assets: rows });
  sync("assets", rows);
}

export function saveTroubles(rows: Troubleshoot[]) {
  patchCache({ troubles: rows });
  sync("troubleshoots", rows);
}

export function saveHistory(rows: AssetHistory[]) {
  patchCache({ history: rows });
  sync("asset_history", rows);
}

export function logAssetChange(entry: Omit<AssetHistory, "id" | "changedAt">) {
  const history = getHistory();
  saveHistory([
    {
      ...entry,
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      changedAt: new Date().toISOString(),
    },
    ...history,
  ]);
}

/* ---------- users (admin operations run server-side) ---------- */

export async function createUser(input: {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: Role;
  password: string;
}): Promise<{ ok: boolean; error?: string }> {
  try {
    await itsmCreateUser({ data: { token: getToken(), ...input } });
    await hydrate(true);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Gagal membuat user." };
  }
}

export async function updateUser(
  id: string,
  patch: { role?: Role; status?: AppUser["status"] },
): Promise<{ ok: boolean; error?: string }> {
  try {
    await itsmUpdateUser({ data: { token: getToken(), id, ...patch } });
    await hydrate(true);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Gagal memperbarui user." };
  }
}

export type ResetEmailPreview = { to: string; subject: string; body: string };

export async function setUserPassword(input: {
  targetUserId: string;
  newPassword: string;
  currentPassword?: string;
}): Promise<{ ok: boolean; error?: string; email?: ResetEmailPreview | null }> {
  try {
    const res = await itsmSetPassword({ data: { token: getToken(), ...input } });
    if (!res.ok) return { ok: false, error: res.error ?? "Gagal mengubah password." };
    return { ok: true, email: res.email ?? null };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Gagal mengubah password." };
  }
}

/* ---------- export helpers ---------- */

type Row = Record<string, string | number>;

function toWorkbook(rows: Row[], sheetName = "Laporan") {
  const sheet = XLSX.utils.json_to_sheet(rows.length ? rows : [{ Info: "Tidak ada data" }]);
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, sheetName.slice(0, 31));
  return book;
}

function xlsxName(filename: string) {
  return filename.replace(/\.(csv|xlsx?)$/i, "") + ".xlsx";
}

export function downloadXLSX(filename: string, rows: Row[]) {
  XLSX.writeFile(toWorkbook(rows, filename), xlsxName(filename));
}

/** Legacy name kept: now produces a real Excel (.xlsx) file. */
export const downloadCSV = downloadXLSX;

export async function uploadReportToDrive(
  filename: string,
  rows: Row[],
): Promise<{ ok: boolean; error?: string; link?: string }> {
  try {
    const out = XLSX.write(toWorkbook(rows, filename), { bookType: "xlsx", type: "base64" });
    const res = await itsmUploadToDrive({
      data: {
        token: getToken(),
        filename: xlsxName(filename),
        base64: out,
        mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      },
    });
    return res;
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Upload gagal." };
  }
}

/** Legacy helper: opens Google Drive in a new tab. */
export function openGoogleDriveUpload() {
  window.open("https://drive.google.com/drive/my-drive", "_blank", "noopener,noreferrer");
}

/* ---------- pengaturan admin ---------- */

export type { AdminSettings, DomainEntry } from "./itsm.functions";
export { DEFAULT_SETTINGS } from "./itsm.functions";

export async function loadSettings() {
  return itsmGetSettings({ data: { token: getToken() } });
}

export async function saveSettings(key: "domains" | "drive" | "email", value: unknown) {
  return itsmSaveSettings({ data: { token: getToken(), key, value } });
}
