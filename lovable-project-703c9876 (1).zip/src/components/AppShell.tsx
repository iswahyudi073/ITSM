import { useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import type { FileRoutesByFullPath } from "@/routeTree.gen";
import {
  LayoutDashboard,
  Ticket,
  Wrench,
  Boxes,
  Users,
  FileBarChart,
  KeyRound,
  LogOut,
  Menu,
  X,
  ShieldCheck,
  Settings,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { logout, type Session } from "@/lib/itsm-store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/tickets", label: "Ticketing", icon: Ticket },
  { to: "/troubleshooting", label: "Troubleshooting", icon: Wrench },
  { to: "/assets", label: "Aset & Inventaris", icon: Boxes },
  { to: "/users", label: "User & Akses", icon: Users },
  { to: "/reports", label: "Laporan", icon: FileBarChart },
  { to: "/account", label: "Reset Password", icon: KeyRound },
  { to: "/settings", label: "Pengaturan", icon: Settings },
] as const satisfies ReadonlyArray<{
  readonly to: keyof FileRoutesByFullPath;
  readonly label: string;
  readonly icon: LucideIcon;
}>;

export function AppShell({
  session,
  title,
  description,
  actions,
  children,
}: {
  session: Session;
  title: string;
  description?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const handleLogout = () => {
    logout();
    navigate({ to: "/", replace: true });
  };

  return (
    <div className="min-h-screen bg-background lg:flex">
      <aside
        className={cn(
          "no-print fixed inset-y-0 left-0 z-40 w-72 flex-col bg-sidebar text-sidebar-foreground transition-transform lg:static lg:flex lg:translate-x-0",
          open ? "flex translate-x-0" : "hidden -translate-x-full lg:flex",
        )}
      >
        <div className="flex items-center gap-3 border-b border-sidebar-border px-5 py-5">
          <div className="flex size-10 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
            <ShieldCheck className="size-5" />
          </div>
          <div>
            <p className="text-base font-semibold tracking-tight">DeancaITSM</p>
            <p className="text-xs text-sidebar-foreground/70">IT Service Management</p>
          </div>
          <button
            className="ml-auto lg:hidden"
            onClick={() => setOpen(false)}
            aria-label="Tutup menu"
          >
            <X className="size-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto p-3">
          {NAV.map(({ to, label, icon: Icon }) => {
            const active = pathname === to || pathname.startsWith(to + "/");
            return (
              <Link
                key={to}
                to={to}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                )}
              >
                <Icon className="size-4" />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-sidebar-border p-4">
          <p className="text-sm font-medium">{session.fullName}</p>
          <p className="text-xs capitalize text-sidebar-foreground/70">
            {session.username} · {session.role}
          </p>
          <Button variant="secondary" size="sm" className="mt-3 w-full" onClick={handleLogout}>
            <LogOut className="size-4" /> Keluar
          </Button>
        </div>
      </aside>

      {open && (
        <div
          className="no-print fixed inset-0 z-30 bg-foreground/40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="no-print sticky top-0 z-20 flex items-center gap-3 border-b bg-card/90 px-4 py-4 backdrop-blur md:px-8">
          <button className="lg:hidden" onClick={() => setOpen(true)} aria-label="Buka menu">
            <Menu className="size-5" />
          </button>
          <div className="min-w-0">
            <h1 className="truncate text-lg font-semibold md:text-xl">{title}</h1>
            {description && <p className="truncate text-sm text-muted-foreground">{description}</p>}
          </div>
          <div className="ml-auto flex flex-wrap items-center justify-end gap-2">{actions}</div>
        </header>
        <main className="flex-1 space-y-6 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}

export function StatusPill({ value }: { value: string }) {
  const map: Record<string, string> = {
    Open: "bg-info/15 text-info",
    "In Progress": "bg-warning/20 text-warning-foreground",
    Pending: "bg-muted text-muted-foreground",
    Resolved: "bg-success/15 text-success",
    Closed: "bg-secondary text-secondary-foreground",
    High: "bg-destructive/15 text-destructive",
    Normal: "bg-info/15 text-info",
    Low: "bg-muted text-muted-foreground",
    "In Use": "bg-success/15 text-success",
    "In Stock": "bg-info/15 text-info",
    Maintenance: "bg-warning/20 text-warning-foreground",
    Retired: "bg-muted text-muted-foreground",
    Active: "bg-success/15 text-success",
    Inactive: "bg-destructive/15 text-destructive",
    Escalated: "bg-destructive/15 text-destructive",
    Monitoring: "bg-warning/20 text-warning-foreground",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        map[value] ?? "bg-secondary text-secondary-foreground",
      )}
    >
      {value}
    </span>
  );
}
